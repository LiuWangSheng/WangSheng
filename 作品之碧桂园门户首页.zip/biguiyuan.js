window.onload = function() {
  var picmove = document.getElementById('picmove');
  var pics = document.getElementById('pics');
  var turnright = document.getElementById('turnright');
  var turnleft = document.getElementById('turnleft');
  var buttons = document.getElementById('buttonpic').getElementsByTagName('span');
  var index=1;
  var timer=null;
  var animateing = false;
  function animate(offset){
    if (offset==0) {return}
    animateing = true;
    var timing=300;
    var interval=8;
    var speeding=offset/(timing/interval);
    var newleft = parseInt(pics.style.left) + offset;
    function went(){
    if ((speeding>0&&parseInt(pics.style.left)<newleft)||(speeding<0&&
      parseInt(pics.style.left)>newleft)) {
      pics.style.left=parseInt(pics.style.left)+speeding+'px';
    setTimeout(went,interval)
    }
    else{
      pics.style.left = newleft + 'px';
       if (newleft>-332) {
      pics.style.left = -1992 + 'px'
    }
    if (newleft<-1992) {
      pics.style.left = -332 +'px'
     }animateing = false;
    }
  }
   went();
  }

function showbutton(){
  for (var i = 0; i < buttons.length; i++) {
    if (buttons[i].className=='on') {
      buttons[i].className='';
      break;
    }
  }
  buttons[index-1].className = 'on';
}

  turnright.onclick = function(){
    if (animateing) {return}
    if (index==6) {
      index=1
    }
    else{
      index +=1;
    }
    showbutton();
    animate(-332);
  }

  turnleft.onclick = function(){
    if (animateing) {return}
    if (index==1) {
      index=6
    }
    else{
      index -=1;
    }
    showbutton();
    animate(332);
  }
  for (var i = 0; i < buttons.length; i++) {
    buttons[i].onclick=function(){
      if (this.className =='on') {
            return;
          }
    var indexes = parseInt(this.getAttribute('index'));
    var offset = -332*(indexes-index);
    index = indexes;
    animate(offset);
    showbutton();
    }
  }

  function play(){
   timer=setInterval(function()
  {turnright.onclick()}
  ,3000)
}
function stop(){
  clearInterval(timer)
}


picmove.onmouseover=stop;
picmove.onmouseout=play;
play();//图片轮播



var newstit1 = document.getElementById('newstit1');
var newstit2 = document.getElementById('newstit2');
var newsmain = document.getElementById('newsmain');
var newsmainer = document.getElementById('newsmainer');

newstit2.onclick=function(){
  newsmain.style.display = 'none';
  newsmainer.style.display = 'block';
  newsmainer.className = 'newsmain';
}
newstit1.onclick = function(){
  newsmainer.style.display = 'none';
  newsmain.style.display = 'block';
}//新闻面板信息切换


var needs11 = document.getElementById('needs11');
var needs12 = document.getElementById('needs12');
var needstip = document.getElementById('needstip');
var needstiper = document.getElementById('needstiper');
needs12.onclick = function(){
  needstip.style.display = 'none';
  needstiper.style.display = 'block';
  needstiper.className='needstip';
}
needs11.onclick = function(){
  needstiper.style.display = 'none';
  needstip.style.display = 'block';
}//待办待阅切换效果


var mainphoto = document.getElementById('mainphoto');
var mainphotos = document.getElementById('mainphotos');
var mbtright = document.getElementById('mbtright');
var mbtleft = document.getElementById('mbtleft');
var mbt = document.getElementById('mbtpic').getElementsByTagName('span');
var index1 = 1;
var animated = false;
var timed = null;
function showbutton1(){
  for (var i = 0; i < mbt.length; i++) {
    if (mbt[i].className =='un') {
      mbt[i].className = '';
    }
    mbt[index1-1].className = 'un';
  }
}

function animate1(offsets){
  if (offsets==0) {return}
    animated = true;
  var time = 300;
  var inteval = 5;
  var speed = offsets/(time/inteval);
  var newlefts = parseInt(mainphotos.style.left) + offsets;
  function go(){
    if ((speed>0&&parseInt(mainphotos.style.left)<newlefts)||(speed<0&&
      parseInt(mainphotos.style.left)>newlefts)) {
      mainphotos.style.left = parseInt(mainphotos.style.left) + speed +'px';
      setTimeout(go,inteval);
    }
    else{
  mainphotos.style.left = newlefts + 'px';
  if (newlefts<-4092) {
    mainphotos.style.left = -682 +'px'
  }
  if (newlefts>-682) {
    mainphotos.style.left = -4092 +'px'
  }animated = false;
    }
  } 
  go();
}
 mbtright.onclick = function(){
  if (animated) {return}
  if (index1==6) {
    index1=1
  }else{
    index1+=1;
  }
  animate1(-682);
  showbutton1()
}
 mbtleft.onclick = function(){
  if (animated) {return}
  if (index1==1) {
    index1=6
  }else
  {index1-=1;
  }
  animate1(682);
  showbutton1()
}

for (var i = 0; i < mbt.length; i++) {
  mbt[i].onclick = function(){
    if (this.className =='un') {
            return;
          }
    var myindex = parseInt(this.getAttribute('index'));
    var offsets = -682*(myindex-index1);
    index1 = myindex;
    animate1(offsets);
    showbutton1();
  }
}
function playing(){
timed = setInterval(function(){
 mbtright.onclick()
},3000)
}
function stoping(){
  clearInterval(timed)
}
mainphoto.onmouseover = stoping;
mainphoto.onmouseout = playing;
playing();//主体图片轮播

var wangzhan = document.getElementById('wangzhan');
var wangzhantop1 = document.getElementById('wangzhantop1');
var wangzhantop2 = document.getElementById('wangzhantop2');
var wangzhanmain1 = document.getElementById('wangzhanmain1');
var wangzhanmain2 = document.getElementById('wangzhanmain2');
wangzhantop2.onclick = function(){
  wangzhanmain1.style.display = 'none';
  wangzhanmain2.style.display = 'block';
  wangzhanmain2.className = 'wangzhanmain'
}
wangzhantop1.onclick = function(){
   wangzhanmain2.style.display = 'none';
   wangzhanmain1.style.display = 'block';
}
//集团网站

var btn = document.getElementById('btn');
var timers = null;
window.onscroll = function(){
  var ostop = document.documentElement.scrollTop || document.body.scrollTop;
  if (ostop>=100) {
    btn.style.display = 'block'
  }
  else{
    btn.style.display = 'none'
  }
}
btn.onclick=function(){
  timers =setInterval(function(){
    var ostop = document.documentElement.scrollTop || document.body.scrollTop; 
    var ispeed = ostop/5;
    document.documentElement.scrollTop = document.body.scrollTop = ostop-ispeed;
    if (ostop==0) {
      clearInterval(timers)
    }
  },30)
}
//回到顶部

var tits=document.getElementById("messagestit").getElementsByTagName("li");
var divs=document.getElementById("con").getElementsByTagName("div"); 
for (var i = 0; i < tits.length; i++) {
  tits[i].id=i;
  tits[i].onclick=function(){
    for (var j = 0; j < tits.length; j++) {
      tits[j].className='';
      divs[j].style.display="none";
    }
    this.className="selects";
    divs[this.id].style.display="block";
  }
}//通知内容切换

var rkt=document.getElementById("rankstop").getElementsByTagName("li");
var dives=document.getElementById("ron").getElementsByTagName("div");
for (var i = 0; i < rkt.length; i++) {
  rkt[i].id=i;
  rkt[i].onclick=function(){
    for (var j = 0; j < rkt.length; j++) {
      rkt[j].className='';
      dives[j].style.display="none";
    }
   this.className="bon";
   dives[this.id].style.display="block";
  }
}


}